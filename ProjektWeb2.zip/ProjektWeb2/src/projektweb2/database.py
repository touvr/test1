from pymongo import MongoClient

client = MongoClient(
    host='mongodb://admin:pass@localhost',
    port=8081,
)




db = client.get_database('mushroom-data')