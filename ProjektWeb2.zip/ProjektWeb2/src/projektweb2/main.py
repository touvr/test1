
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from pymongo import MongoClient
from pydantic import BaseModel

import pymongo
from authlib.integrations.starlette_client import OAuth, OAuthError
from starlette.middleware.sessions import SessionMiddleware
from starlette.config import Config
import os
from typing import List

from .model import Mushroom




app = FastAPI()
client = pymongo.MongoClient("mongodb://localhost:27017/Mushrooms")
db = client.get_database('Mushrooms')

print(f"{db.name} collections: {db.list_collection_names()}")
GOOGLE_CLIENT_ID = "1056412669237-cr8ibkhch1htouto1lm32pcbsbvqrmsh.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET = "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"
SECRET_KEY = "6U53G_PUXj401wlHo6IFOvRW0wwaPn6poMxAAHFMA5k"
@app.get('/')
async def root():
    return HTMLResponse('''
<body>
    <a href="/auth/login">Log In with Google</a>
</body>''')
starlette_config = Config(environ={
    "GOOGLE_CLIENT_ID": GOOGLE_CLIENT_ID,
    "GOOGLE_CLIENT_SECRET": GOOGLE_CLIENT_SECRET
})
oauth = OAuth(starlette_config)
oauth.register(
    name="google",
    server_metadata_url='https://accounts.google.com/.well-known/openid-configuration',
    client_kwargs={'scope': 'openid email profile'},
)

app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY)

@app.get('/auth/login')
async def login(request: Request):
    redirect_uri = "http://localhost:8000/callback"  
    return await oauth.google.authorize_redirect(request, redirect_uri)



@app.get('/callback')
async def token(request: Request):
    try:
        token = await oauth.google.authorize_access_token(request)
        user_info = token.get('userinfo') 
        if user_info:
            request.session['user'] = user_info
            return RedirectResponse(url='/home')
        else:
            raise HTTPException(status_code=401, detail="Failed to login")
    except OAuthError as e:
        return {"error": str(e)}
    
@app.get("/home")
async def home(request: Request):
    user = request.session.get('user')
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return {"message": f"Welcome to the Home Page, {user.get('name', 'Guest')}!"}

@app.get('/mushroom')
async def get_mushrooms() -> list[Mushroom]:
    return list(db['mushroom-data'].find())

@app.post('/mushroom-post', status_code=201)
async def post_mushrooms(mushroom: Mushroom):


    response = db['mushroom-data'].insert_one(mushroom.dict(by_alias=True))
    
    # If the insertion was successful, return the inserted mushroom's id
    if response.acknowledged:
        return {"id": str(response.inserted_id)}
    
    # If the insertion failed, raise an HTTP exception
    raise HTTPException(status_code=400, detail="Insertion failed")


if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='localhost', port=8000)


