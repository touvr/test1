from pymongo import MongoClient

client = MongoClient(
    host='mongodb://root:example@localhost',
    port=27017,
)

# Create database if it doesn't exist
if 'mushroom-data' not in client.list_database_names():
    client.create_database('mushroom-data')


db = client.get_database('mushroom-data')