
from pydantic import BaseModel

class Mushroom(BaseModel):
    name: str
    average_weight: float
    color: str
    location: str
    rarity: str
