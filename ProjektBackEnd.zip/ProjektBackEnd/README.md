# ProjektBackEnd
docker-compose build
docker-compose up
pdm run dev
pdm install
# Další užitečné příkazy:
- `pdm update`: Aktualizuje závislosti projektu.
- `pdm lock`: Zajišťuje, že jsou použity přesně definované verze závislostí.
- `pdm clean`: Odstraňuje dočasné soubory a složky v projektu.
- `pdm run test`: Spouští testy v projektu.
- `pdm run lint`: Spouští linter pro kontrolu kódu.
- `pdm run format`: Formátuje kód v projektu.
- `pdm run migrate`: Provádí migrace databáze.
- `pdm run seed`: Provádí inicializaci databáze pomocí seed dat.
- `docker ps`: Zobrazuje běžící kontejnery.
- `docker stop <container_id>`: Zastavuje běžící kontejner s daným ID.
- `docker rm <container_id>`: Odstraňuje kontejner s daným ID.
- `docker rmi <image_id>`: Odstraňuje obraz s daným ID.
- `docker images`: Zobrazuje dostupné obrazy.
- `docker exec -it <container_id> <command>`: Spouští příkaz uvnitř běžícího kontejneru.
- `docker-compose down`: Zastavuje a odstraňuje všechny kontejnery definované v docker-compose.yml.
- `docker-compose restart <service_name>`: Restartuje konkrétní službu definovanou v docker-compose.yml.
- `docker-compose logs <service_name>`: Zobrazuje logy pro konkrétní službu definovanou v docker-compose.yml.



- ` >>> import secrets
- ` >>> secrets.token_urlsafe()
- ` 'vJQGdJ9ATBO53NKmsvO2A4D1hIUw8HTyMq0chYWrGb0'
'K13D8CvY-2WARFgM-WUgJb02vh5xmyluuPmCHQ8M86E'